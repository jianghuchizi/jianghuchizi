//>>built
define(["./flash/_base"],function(){});