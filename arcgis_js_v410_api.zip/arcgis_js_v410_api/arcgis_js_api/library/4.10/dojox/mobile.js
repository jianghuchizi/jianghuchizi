//>>built
define([".","dojo/_base/lang","dojox/mobile/_base"],function(a,b,c){b.getObject("mobile",!0,a);return a.mobile});