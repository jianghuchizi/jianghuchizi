//>>built
define(["./highlight/_base"],function(a){return a});