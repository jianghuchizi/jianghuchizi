//>>built
define(["./create"],function(a){return a("CancelError",null,null,{dojoType:"cancel",log:!1})});