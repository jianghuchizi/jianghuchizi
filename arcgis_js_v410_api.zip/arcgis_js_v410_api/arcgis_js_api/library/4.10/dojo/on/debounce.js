//>>built
define(["../debounce","../on","./asyncEventListener"],function(a,b,c){return function(d,e){return function(f,g){return b(f,d,c(a(g,e)))}}});