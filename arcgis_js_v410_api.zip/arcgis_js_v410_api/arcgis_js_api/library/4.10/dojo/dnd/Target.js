//>>built
define(["../_base/declare","../dom-class","./Source"],function(a,b,c){return a("dojo.dnd.Target",c,{constructor:function(){this.isSource=!1;b.remove(this.node,"dojoDndSource")}})});