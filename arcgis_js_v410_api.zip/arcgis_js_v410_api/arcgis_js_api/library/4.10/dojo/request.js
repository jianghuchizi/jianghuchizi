//>>built
define(["./request/default!"],function(a){return a});