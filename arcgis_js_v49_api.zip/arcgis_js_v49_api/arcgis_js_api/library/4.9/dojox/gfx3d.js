//>>built
define(["dojo/_base/kernel","dojox","./gfx3d/matrix","./gfx3d/_base","./gfx3d/object"],function(b,a){b.getObject("gfx3d",!0,a);return a.gfx3d});