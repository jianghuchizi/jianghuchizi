// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.9/esri/copyright.txt for details.
//>>built
define("require exports ./geometry/Extent ./geometry/Geometry ./geometry/Mesh ./geometry/Multipoint ./geometry/Point ./geometry/Polygon ./geometry/Polyline ./geometry/ScreenPoint ./geometry/SpatialReference ./geometry/support/jsonUtils".split(" "),function(n,a,b,c,d,e,f,g,h,k,l,m){Object.defineProperty(a,"__esModule",{value:!0});a.Extent=b;a.BaseGeometry=c;a.Mesh=d;a.Multipoint=e;a.Point=f;a.Polygon=g;a.Polyline=h;a.ScreenPoint=k;a.SpatialReference=l;a.isGeometry=function(b){return b instanceof a.BaseGeometry};
a.fromJSON=m.fromJSON});